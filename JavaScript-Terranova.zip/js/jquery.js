$(document).ready(function(){
  $(".showMore").click(function(){
    $(".jqDisplay").fadeToggle();
    $(".showMore").text("Ver Menos");
  });
  
});

